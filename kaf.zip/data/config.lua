do local _ = {
  admins = {},
  disabled_channels = {},
  enabled_plugins = {
    "kaf"
  },
  info_text = "kaf V 2.1\n",
  moderation = {
    data = "./data/moderation.json"
  },
  sudo_users = {
    100481835,
  }
}
return _
end